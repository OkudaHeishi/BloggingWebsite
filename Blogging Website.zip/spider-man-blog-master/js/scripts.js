// Code by Emre Kuru B00837309

M.AutoInit();

function toggle() {
    $('#post').slideToggle("slow");
}

function addLike(id) {
    const xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
        if (this.readyState === 4 && this.status === 200) {
            $("#" + id).load(" #" +id);
            M.toast({html: 'Liked!', classes: 'rounded light-blue'});

        }
    };

    xmlhttp.open("GET","includes/process_likes.php?id="+id,true);
    xmlhttp.send();

}


// Code by Hesham Elokdah B00843961
// Used addLike() implemented by Emre Kuru as reference

function follow(test) {
    const xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
        if (this.readyState === 4 && this.status === 200) {
            $("#" + test).load(" #" +test);
            M.toast({html: 'Following!', classes: 'rounded light-blue'});

        }
    };
    xmlhttp.open("GET","includes/follow.php?id="+test,true);
    xmlhttp.send();
    
}

function block(test2) {
    const xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
        if (this.readyState === 4 && this.status === 200) {
            $("#" + test2).load(" #" +test2);
            M.toast({html: 'Blocked!', classes: 'rounded light-blue'});

        }
    };
    xmlhttp.open("GET","includes/block.php?id="+test2,true);
    xmlhttp.send();
}
