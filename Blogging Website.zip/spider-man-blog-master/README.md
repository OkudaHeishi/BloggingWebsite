# CSCI 2170: Winter 2021, Online Edition, Group Assignment 

## Students information
- Full name: Kaushik Dhamodaran
- Banner ID (B00#): B00855259
- Dal email: ks695041@dal.ca

- Full name: Emre Kuru
- Banner ID (B00#): B00837309
- Dal email: ekuru@dal.ca

- Full name: Raunak Singh
- Banner ID (B00#): B00831843
- Dal email: rn936180@dal.ca

- Full name: Sabiha Khan
- Banner ID (B00#): B00842047
- Dal email: sb670504@dal.ca

- Full name: Hesham Elokdah
- Banner ID (B00#): B00843961
- Dal email: Hesham.Elokdah@dal.ca
## Site name
Spider-Man blog

## Site summary


## Citations and notes
1. Used W3School as reference:
URL: https://www.w3schools.com/
Date Accessed: 08 April 2021.

2.  This code to implement the displaying of individual posts in more detail has been used with some modification from my submission for Assignment 3
    in CSCI 2170 (Winter 2021).
    Sabiha Khan,Assignment 3: CSCI 2170 (Winter 2021), Faculty of Computer Science, Dalhousie University.
    Available online on Gitlab at [URL]: https://git.cs.dal.ca/courses/2021-winter/csci-2170/a2/sabiha.
    Date accessed: April 4, 2021.


## Contributions
1. Kaushik Dhamodaran: Database construction and retrival
2. Raunak Singh: Implemented User Stories #2 & #7
3. Hesham Elokdah: Implemented User Stories #4 & #12
4. Sabiha Khan: Implemented User Stories #6 & #11.
5. Emre Kuru: Implemented the website design, animations and login and registration pages.

## Game hosts websites
- Kaushik Dhamoadaran: https://web.cs.dal.ca/~dhamodaran/
- Emre Kuru: https://web.cs.dal.ca/~kuru/
- Sabiha Khan: https://web.cs.dal.ca/~sabiha/
- Raunak Singh: https://web.cs.dal.ca/~raunak
- Hesham Elokah: https://web.cs.dal.ca/~elokah/
