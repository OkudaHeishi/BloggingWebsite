<?php
/**
 * Implemented by Hesham Elokdah B00843961
 */
session_start();
require_once "db.php";

$table = "tweeps";

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $query = "INSERT INTO `block` VALUES ('$_SESSION[id]','$id');";
    if (isset($dbconnection)) {
        $result = $dbconnection->query($query);
    }
}
