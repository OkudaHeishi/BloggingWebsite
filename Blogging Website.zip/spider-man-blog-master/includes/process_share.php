<?php 
    session_start();

    //Implemented by Sabiha Khan - B00842047
    require_once "db.php";

    $tweeps_id = $_GET['id'];

    //Updates the number of shares of the ccurrent post.

    $query =  $query = "UPDATE `tweeps` SET shared = shared + 1 WHERE id = '$tweeps_id'";
    $result = $dbconnection->query($query);

    //Selects data from the currnt post
    $query1 = "SELECT * FROM `tweeps` WHERE `id` = '$tweeps_id' ";
    $sql1 = $dbconnection->query($query1);

    foreach($sql1 as $row){

        $author = $_SESSION["firstname"] .' '. $_SESSION["lastname"];
        $username = $_SESSION["username"];
        $date = date("Y-m-d");
        $content = $row['post_content'];

        //Inserts new data from the current post to a new row but with diffrent author and date.
        $thisID=$_SESSION['id'];
        $query2 = "INSERT INTO `tweeps` (author, author_id, username, post_date, post_content, likes, shared) 
            VALUES ('$author', '$thisID', '$username', '$date', '$content', 0, 0)";

        $sql = $dbconnection->query($query2);

        if (!$sql) {
        die("Error in executing the query: ($dbconnection->errno) $dbconnection->error<br>SQL = $query");
        }
        else{
        header('Location: ../index.php');
        }
    }

?>