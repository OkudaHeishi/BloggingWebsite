<?php 
    session_start();

    //Implemented by Sabiha Khan - B00842047
    require_once "db.php";

    $tweeps_id = $_GET['id'];

    //Deletes the post selected.
    $query = "DELETE FROM `tweeps` WHERE `id` = '$tweeps_id' ";
    $sql = $dbconnection->query($query);

    if (!$sql) {
        die("Error in executing the query: ($dbconnection->errno) $dbconnection->error<br>SQL = $query");
    }
    else{
        header('Location: ../index.php?tweep_deleted');
    }
?>