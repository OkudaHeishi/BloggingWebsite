<?php
	//DB connection script by Kaushik Dhamodaran B00855259
	$hostservername = "localhost";
	$username = "root";
	$password = "root";
	$dbname = "JediTweeps";

	$dbconnection = new mysqli($hostservername, $username, $password, $dbname);

	if ($dbconnection->connect_error) {
		die("Nooooooooo<br>" . $dbconnection->connect_error);
	}

