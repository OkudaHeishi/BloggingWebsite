<!-- Coded By: Raunak Singh
Bannerd ID: B00831843 -->

<?php

session_start();
require_once "db.php";

    $username = htmlspecialchars(stripslashes(trim($_POST["username"]))); // Data sanitization
    $password = htmlspecialchars(stripslashes(trim($_POST["password"]))); // Data sanitization
    $confirmPassword = htmlspecialchars(stripslashes(trim($_POST["confirm-password"]))); // Data sanitization
    $firstName = htmlspecialchars(stripslashes(trim($_POST["firstname"]))); // Data sanitization
    $lastName = htmlspecialchars(stripslashes(trim($_POST["lastname"]))); // Data sanitization

    $query = "UPDATE `login` SET `username`='$username',`password`='$password',`firstname`='$firstName',`lastname`='$lastName' WHERE id = '$_SESSION[id]'";

    if ($dbconnection->query($query)) {
    }
    else {
        echo "Noooooooooooooo";
        die("Error ($dbconnection->errno) $dbconnection->error");
    }
    $_SESSION['edit-success'] = 1;
    header("Location: ../profile.php");

?>



