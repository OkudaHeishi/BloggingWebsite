<?php

    session_start();
    /**
     * Initial code by Kaushik Dhamodaran B00855259
     * Modified by Sabiha Khan - B00842027
     * Updated by Hesham Elokdah B00843961
     */
    require_once "db.php";



    if (isset($_POST['action'])){

        $content = trim(stripslashes(htmlspecialchars($_POST["textarea"])));
        $date = date("Y-m-d");

        //Inserts the blog post into the database and redircts user
        $FName = $_SESSION[firstname].' '. $_SESSION[lastname];
        $querySQL = "INSERT INTO `tweeps` (author, author_id, username, post_date, post_content, likes, shared) 
                    VALUES ('$FName', ' $_SESSION[id]', ' $_SESSION[username]', '$date', '$content', 0, 0)";

        $result = $dbconnection->query($querySQL);

        if (!$result) {
        die("Error in executing the query: ($dbconnection->errno) $dbconnection->error<br>SQL = $query");
        }
        else{
        header('Location: ../index.php');
        }
    }
?>
