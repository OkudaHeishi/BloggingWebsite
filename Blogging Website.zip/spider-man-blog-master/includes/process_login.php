<?php

session_start();
// Include your login processing script here.
require_once "db.php";


$table = "login";


if (isset($_POST["username"]) || isset($_POST["password"])) {
    $username = htmlspecialchars(stripslashes(trim($_POST["username"]))); // Data sanitization
    $password = htmlspecialchars(stripslashes(trim($_POST["password"]))); // Data sanitization
    $query = "SELECT * FROM $table WHERE username = '" . $username . "' and password = '". $password."'";

    if (isset($dbconnection)) {
        $result = $dbconnection->query($query);

        if ($result) {
            if (!mysqli_num_rows($result) == 0) {
                while ($row = $result->fetch_assoc()) {
                    $_SESSION["id"] = $row['id'];
                    $_SESSION["firstname"] = $row['firstname'];
                    $_SESSION["lastname"] = $row['lastname'];
                    $_SESSION["username"] = $row['username'];
                    $_SESSION["password"] = password_hash($row['password'], PASSWORD_DEFAULT); // Hash the password
                }

            } else {
                echo "Invalid Username or Password!";
            }
        } else {
            echo "<p> Cannot connect to the database</p>";
        }

    }
}



if(isset($_SESSION["id"]) && isset($_SESSION["firstname"])) {
    header("Location:../index.php");
} else {
    header("Location:../login.php?pswd");
}



?>

