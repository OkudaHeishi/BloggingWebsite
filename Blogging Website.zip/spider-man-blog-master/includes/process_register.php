<?php

session_start();
// Include your login processing script here.
require_once "db.php";


if (isset($_POST["username"]) || isset($_POST["password"])) {
    $firstname = htmlspecialchars(stripslashes(trim($_POST["firstname"]))); // Data sanitization
    $lastname = htmlspecialchars(stripslashes(trim($_POST["lastname"]))); // Data sanitization
    $username = htmlspecialchars(stripslashes(trim($_POST["username"]))); // Data sanitization
    $password = htmlspecialchars(stripslashes(trim($_POST["password"]))); // Data sanitization

    $query = "INSERT INTO `login` (`username`, `password`, `firstname`, `lastname`)
                VALUES ('$username', '$password', '$firstname', '$lastname');";

    if (isset($dbconnection)) {
        $result = $dbconnection->query($query);

        if ($result) {
            header("Location:../login.php?register");
        }
    }
}

