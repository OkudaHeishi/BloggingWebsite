<?php
// Code by Emre Kuru B00837309
session_start()

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!--Import Google Icon Font-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!--Import materialize.css-->
    <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
    <link type="text/css" rel="stylesheet" href="css/styles.css"/>

    <!--Let browser know website is optimized for mobile-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>

    <title>Jedi Tweeps</title>
</head>
<header>
    <?php
    if(isset($_SESSION['id'])) {
        echo "<div class='nav'>
                <ul id='slide-out' class='sidenav'>
                    <li>
                        <div class='user-view'>
                            <div class='background'>
                                <img src='images/logo.svg'>
                            </div>
                            <a href='#user' class='circle'><i class='material-icons' style='font-size: 400%; color: white'>person_outline</i></a>
                            <a href='#name'><span class='white-text name'> $_SESSION[firstname] $_SESSION[lastname] </span></a>
                            <a href='#email'><span class='white-text email'></span></a>
                        </div>
                    </li>
                    <li><a href='index.php''><i class='material-icons'>gradient</i>Tweeps</a></li>
                    <li>
                        <div class='divider'></div>
                    </li>
                    <li><a class='waves-effect' href='profile.php'><i class='material-icons'>contacts</i>Profile</a></li>
                    <li>
                        <div class='divider'></div>
                    </li>
                    <li><a class='waves-effect' href='includes/process_logout.php'><i class='material-icons'>fast_forward</i>Logout</a></li>
                </ul>
                <div class='nav-wrapper'>
                    <a href='#' data-target='slide-out' class='sidenav-trigger'>
                        <i class='material-icons' style='font-size: 395%; color: white;'>person_outline</i>
                    </a>
                </div>
                <nav>";
        ?>
        <?php
        echo '<form class="nav-wrapper" method="get">
                    <a href="index.php" class="brand-logo center"  style="padding-right: 4%">Jedi Tweeps</a>
                    <ul id="nav-mobile" class="left hide-on-med-and-down">
                        <li><a href="index.php">Tweeps</a></li>
                        <li onclick="toggle()"><a>Post a tweep</a></li>
                        <li><a href="find.php">Find bloggers</a></li>
                    </ul>
                    <ul class="right hide-on-med-and-down">
                        <li>
                            <button type="submit" class="btn btn-outline-primary light-blue"
                                    style="border: white solid 1px; margin: 14px 5px;">
                                        search
                            </button>
                        </li>
                        <li>
                            <div class="form-outline">
                                <input type="search" id="form1" name="search" class="form-control"
                                       placeholder="search" aria-label="Search" required/>
                            </div>
                        </li>
                    </ul>
                </form>
            </nav>
        </div>';

    } else {
        echo ' <nav class="light-blue">
        <div class=nav-wrapper">
          <a href="#" class="brand-logo center">Jedi Tweeps</a>
        </div>
      </nav>';
    }

    ?>
</header>
