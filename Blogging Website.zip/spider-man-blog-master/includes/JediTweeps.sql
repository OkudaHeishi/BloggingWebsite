-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Apr 03, 2021 at 05:04 PM
-- Server version: 5.7.32
-- PHP Version: 7.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `JediTweeps`
--
CREATE DATABASE IF NOT EXISTS `JediTweeps` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `JediTweeps`;

-- --------------------------------------------------------

--
-- Table structure for table `block`
--

DROP TABLE IF EXISTS `block`;
CREATE TABLE `block` (
                         `blocker_id` int(11) NOT NULL,
                         `blocking_id` int(11) NOT NULL,
			  UNIQUE(blocker_id, blocking_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `follow`
--

DROP TABLE IF EXISTS `follow`;
CREATE TABLE `follow` (
                          `follower_id` int(11) NOT NULL,
                          `following_id` int(11) NOT NULL,
			   UNIQUE(follower_id, following_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
CREATE TABLE `login` (
                         `id` int(11) NOT NULL,
                         `username` varchar(128) NOT NULL,
                         `password` varchar(256) NOT NULL,
                         `firstname` varchar(128) NOT NULL,
                         `lastname` varchar(128) NOT NULL,
                         `admin` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `password`, `firstname`, `lastname`,`admin`) VALUES
(1, 'han', '1234', 'Han', 'Solo', 'yes'),
(2, 'luke', '1234', 'Luke', 'Skywalker', 'yes'),
(3, 'leia', '1234', 'Leia', 'Organa','no'),
(4, 'rey', '1234', 'Rey', 'Skywalker', 'no'),
(5, 'chewb', '1234', 'Chew', 'Bacca', 'no'),
(6, 'CP', '1234', 'C3', '-PO', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `tweeps`
--

DROP TABLE IF EXISTS `tweeps`;
CREATE TABLE `tweeps` (
                         `id` int(11) NOT NULL,
			             `author_id` int(11) NOT NULL,
                          `author` varchar(64) NOT NULL,
                          `username` varchar(50) NOT NULL,
                          `post_date` date NOT NULL,
                          `post_content` varchar(240) NOT NULL,
                          `likes` int(11) NOT NULL,
                          `shared` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tweeps`
--

INSERT INTO `tweeps` (`id`, `author_id` , `author`, `username`, `post_date`, `post_content`, `likes`,`shared`) VALUES
(1, 2, 'Luke Skywalker', 'luke', '1999-01-01', 'New account. I decided I hated using darkSideBlog so now I am here.', 29, 0),
(2, 1, 'Han Solo', 'han', '2001-07-10', 'Luke you forgot to give me back my Millemium Falcon! :(', 20, 0),
(3, 3, 'Leia Organa', 'leia', '2001-07-11', 'Everyone, Im trowing a party on the remains of Alderaan! Everyone with a working starship is welcome!', 15, 0),
(4, 5, 'Chewbacca ', 'chewb', '2001-07-11', 'RAWRARGHHHHHHHHHHHHHHHHHHH', 9, 0),
(5, 6, 'C3-PO ', 'CP', '2001-08-14', 'I have decided that all human forms of social media are bad.', 9, 0),
(6, 4, 'Rey Skywalker', 'rey', '2021-04-03', '', 4, 0),
(7, 4, 'Rey Skywalker', 'rey', '2021-04-03', '', 6, 0),
(11, 1, 'Han Solo', 'han', '2021-04-03', 'asd', 1, 0),
(12, 1, 'Han Solo', 'han', '2021-04-03', 'SADASDASDASD', 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `login`
--
ALTER TABLE `login`
    ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tweeps`
--
ALTER TABLE `tweeps`
    ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
    MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tweeps`
--
ALTER TABLE `tweeps`
    MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
