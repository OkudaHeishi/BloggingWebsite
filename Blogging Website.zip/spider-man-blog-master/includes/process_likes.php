<?php
require_once "db.php";
$table = "tweeps";


if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "UPDATE $table SET likes = likes + 1 WHERE id = $id";

    if (isset($dbconnection)) {
        $result = $dbconnection->query($query);

        if ($result) {
            echo 'Liked';
        }

    }
}
